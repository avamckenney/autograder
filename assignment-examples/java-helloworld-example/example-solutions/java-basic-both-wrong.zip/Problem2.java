public class Problem2{
  public static void main(String[] args){
    for(int i = 0 ; i < 14; i++){
      System.out.println(i);
    }
  }
}