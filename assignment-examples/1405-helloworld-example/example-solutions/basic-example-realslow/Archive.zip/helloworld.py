import time
time.sleep(30)
print("Hello World!")