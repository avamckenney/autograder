for i in range(14):
    print(i)
