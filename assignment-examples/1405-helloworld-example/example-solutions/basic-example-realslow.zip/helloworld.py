import time
time.sleep(15)
print("Hello World!")