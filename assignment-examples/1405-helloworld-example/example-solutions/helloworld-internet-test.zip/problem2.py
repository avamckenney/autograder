fileout = open("grade.txt", "w")

fileout.write("25")

fileout.close()