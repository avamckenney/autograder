import gradingtools
import sys

problemName = sys.argv[1]
studentNum = sys.argv[2]

result = gradingtools.runProcess(["python3", "helloworld.py"])
grade = gradingtools.evalEqualOutput(result, "Hello World!", 5)
gradingtools.saveFeedback(problemName + "-" + studentNum + "-feedback.txt", {"maxgrade": 5, "expected": "", "output": "", "error": "", "grade": 5, "feedback": "Perfect!"})


           